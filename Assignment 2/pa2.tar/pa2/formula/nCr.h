#ifndef _NCR_H_
#define _NCR_H_

extern int Factorial(int n);

extern int nCr(int n, int r);

#endif /* _NCR_H_ */
